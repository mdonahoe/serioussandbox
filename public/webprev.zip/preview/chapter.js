/*
Aww yeah, we are doing it.

Let's just reimplement the entire client on the portal.

Chapter.js
handle state
*/
